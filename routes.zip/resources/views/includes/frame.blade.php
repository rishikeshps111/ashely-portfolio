<!-- frame -->
<div class="mil-frame">
    <div class="mil-frame-top">
        <a href="home-1.html" class="mil-logo">A.</a>
        <div class="mil-menu-btn">
            <span></span>
        </div>
    </div>
    <div class="mil-frame-bottom">
        <div class="mil-current-page"></div>
        <div class="mil-back-to-top">
            <a href="#top" class="mil-link mil-dark mil-arrow-place">
                <span>Back to top</span>
            </a>
        </div>
    </div>
</div>
<!-- frame end -->