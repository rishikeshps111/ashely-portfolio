<!-- curtain -->
<div class="mil-curtain"></div>
<!-- curtain end -->