<!-- scrollbar progress -->
<div class="mil-progress-track">
    <div class="mil-progress"></div>
</div>
<!-- scrollbar progress end -->