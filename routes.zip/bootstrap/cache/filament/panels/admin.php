<?php return array (
  'livewireComponents' => 
  array (
    'joaopaulolndev.filament-edit-profile.pages.edit-profile-page' => 'Joaopaulolndev\\FilamentEditProfile\\Pages\\EditProfilePage',
    'joaopaulolndev.filament-general-settings.pages.general-settings-page' => 'Joaopaulolndev\\FilamentGeneralSettings\\Pages\\GeneralSettingsPage',
    'app.filament.resources.company-collaborations.pages.manage-company-collaborations' => 'App\\Filament\\Resources\\CompanyCollaborations\\Pages\\ManageCompanyCollaborations',
    'app.filament.resources.contact-messages.pages.manage-contact-messages' => 'App\\Filament\\Resources\\ContactMessages\\Pages\\ManageContactMessages',
    'app.filament.resources.newsletter-subscribers.pages.manage-newsletter-subscribers' => 'App\\Filament\\Resources\\NewsletterSubscribers\\Pages\\ManageNewsletterSubscribers',
    'app.filament.resources.project-categories.pages.manage-project-categories' => 'App\\Filament\\Resources\\ProjectCategories\\Pages\\ManageProjectCategories',
    'app.filament.resources.projects.pages.manage-projects' => 'App\\Filament\\Resources\\Projects\\Pages\\ManageProjects',
    'app.filament.resources.service-categories.pages.manage-service-categories' => 'App\\Filament\\Resources\\ServiceCategories\\Pages\\ManageServiceCategories',
    'app.filament.resources.services.pages.manage-services' => 'App\\Filament\\Resources\\Services\\Pages\\ManageServices',
    'app.filament.resources.testimonials.pages.manage-testimonials' => 'App\\Filament\\Resources\\Testimonials\\Pages\\ManageTestimonials',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.contact-chart' => 'App\\Filament\\Widgets\\ContactChart',
    'app.filament.widgets.dashboard-over-view-stat' => 'App\\Filament\\Widgets\\DashboardOverViewStat',
    'app.filament.widgets.subscriber-chart' => 'App\\Filament\\Widgets\\SubscriberChart',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.auth.pages.edit-profile' => 'Filament\\Auth\\Pages\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.livewire.sidebar' => 'Filament\\Livewire\\Sidebar',
    'filament.livewire.simple-user-menu' => 'Filament\\Livewire\\SimpleUserMenu',
    'filament.livewire.topbar' => 'Filament\\Livewire\\Topbar',
    'filament.auth.pages.login' => 'Filament\\Auth\\Pages\\Login',
    'filament.auth.pages.password-reset.request-password-reset' => 'Filament\\Auth\\Pages\\PasswordReset\\RequestPasswordReset',
    'filament.auth.pages.password-reset.reset-password' => 'Filament\\Auth\\Pages\\PasswordReset\\ResetPassword',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Joaopaulolndev\\FilamentEditProfile\\Pages\\EditProfilePage',
    1 => 'Joaopaulolndev\\FilamentGeneralSettings\\Pages\\GeneralSettingsPage',
    2 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\Projects\\ashely-portfolio\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Resources\\CompanyCollaborations\\CompanyCollaborationResource.php' => 'App\\Filament\\Resources\\CompanyCollaborations\\CompanyCollaborationResource',
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Resources\\ContactMessages\\ContactMessageResource.php' => 'App\\Filament\\Resources\\ContactMessages\\ContactMessageResource',
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Resources\\NewsletterSubscribers\\NewsletterSubscriberResource.php' => 'App\\Filament\\Resources\\NewsletterSubscribers\\NewsletterSubscriberResource',
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Resources\\ProjectCategories\\ProjectCategoryResource.php' => 'App\\Filament\\Resources\\ProjectCategories\\ProjectCategoryResource',
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Resources\\Projects\\ProjectResource.php' => 'App\\Filament\\Resources\\Projects\\ProjectResource',
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Resources\\ServiceCategories\\ServiceCategoryResource.php' => 'App\\Filament\\Resources\\ServiceCategories\\ServiceCategoryResource',
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Resources\\Services\\ServiceResource.php' => 'App\\Filament\\Resources\\Services\\ServiceResource',
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Resources\\Testimonials\\TestimonialResource.php' => 'App\\Filament\\Resources\\Testimonials\\TestimonialResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\Projects\\ashely-portfolio\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Widgets\\ContactChart.php' => 'App\\Filament\\Widgets\\ContactChart',
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Widgets\\DashboardOverViewStat.php' => 'App\\Filament\\Widgets\\DashboardOverViewStat',
    'D:\\Projects\\ashely-portfolio\\app\\Filament\\Widgets\\SubscriberChart.php' => 'App\\Filament\\Widgets\\SubscriberChart',
    0 => 'App\\Filament\\Widgets\\DashboardOverViewStat',
    1 => 'App\\Filament\\Widgets\\SubscriberChart',
    2 => 'App\\Filament\\Widgets\\ContactChart',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\Projects\\ashely-portfolio\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);