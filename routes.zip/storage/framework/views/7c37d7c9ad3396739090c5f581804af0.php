<div id="custom-toast" class="custom-toast hidden">
    <i id="toast-icon" class=""></i>
    <div class="toast-text" id="toast-message"></div>
</div><?php /**PATH D:\Projects\ashely-portfolio\resources\views\includes\toast.blade.php ENDPATH**/ ?>