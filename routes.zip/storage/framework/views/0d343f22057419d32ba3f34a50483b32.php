<!-- preloader -->
<div class="mil-preloader">
    <div class="mil-preloader-animation">
        <div class="mil-pos-abs mil-animation-1">
            <p class="mil-h3 mil-muted mil-thin">Pioneering</p>
            <p class="mil-h3 mil-muted">Creative</p>
            <p class="mil-h3 mil-muted mil-thin">Excellence</p>
        </div>
        <div class="mil-pos-abs mil-animation-2">
            <div class="mil-reveal-frame">
                <p class="mil-reveal-box"></p>
                <p class="mil-h3 mil-muted mil-thin">portfolio.com</p>
            </div>
        </div>
    </div>
</div>
<!-- preloader end --><?php /**PATH D:\Projects\ashely-portfolio\resources\views\includes\preloader.blade.php ENDPATH**/ ?>