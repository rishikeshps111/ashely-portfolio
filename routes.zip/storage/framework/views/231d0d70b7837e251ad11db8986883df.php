<!-- bootstrap grid css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/bootstrap-grid.css')); ?>">
<!-- font awesome css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<!-- swiper css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/swiper.min.css')); ?>">
<!-- fancybox css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/fancybox.min.css')); ?>">
<!-- ashley scss -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<!-- page name --><?php /**PATH D:\Projects\ashely-portfolio\resources\views/layouts/style.blade.php ENDPATH**/ ?>