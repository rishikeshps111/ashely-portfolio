

<?php $__env->startSection('title'); ?>
    Project Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- banner -->
    <div class="mil-inner-banner">
        <div class="mil-banner-content mil-up">
            <div class="mil-animation-frame">
                <div class="mil-animation mil-position-4 mil-dark mil-scale" data-value-1="6" data-value-2="1.4">
                </div>
            </div>
            <div class="container">
                <ul class="mil-breadcrumbs mil-mb-60">
                    <li><a href="<?php echo e(route('home')); ?>">Homepage</a></li>
                    <li><a href="<?php echo e(route('portfolio')); ?>">Portfolio</a></li>
                    <li><a href="<?php echo e(route('projectDetails', $project->slug)); ?>">Project</a></li>
                </ul>
                <h1 class="mil-mb-60"><?php echo styledTitle($project->title); ?></h1>
                <a href="#project" class="mil-link mil-dark mil-arrow-place mil-down-arrow">
                    <span>Read more</span>
                </a>
            </div>
        </div>
    </div>
    <!-- banner end -->

    <!-- project -->
    <section>
        <div class="container mil-p-120-120" id="project">
            <div class="row justify-content-between mil-mb-120">
                <div class="col-lg-4">

                    <div class="mil-p-0-120">
                        <ul class="mil-service-list mil-dark mil-mb-60">
                            <?php if($project->client_name): ?>
                                <li class="mil-up">Client: &nbsp;<span class="mil-dark"><?php echo e($project->client_name); ?></span></li>
                            <?php endif; ?>
                            <?php if($project->date): ?>
                                <li class="mil-up">Date: &nbsp;<span
                                        class="mil-dark"><?php echo e(\Carbon\Carbon::parse($project->date)->format('F Y')); ?></span></li>
                            <?php endif; ?>
                            <?php if($project->author): ?>
                                <li class="mil-up">Author: &nbsp;<span class="mil-dark"><?php echo e($project->author); ?></span></li>
                            <?php endif; ?>
                        </ul>

                        <h5 class="mil-up mil-mb-30">
                            <?php echo e(implode(', ', $project->keywords ?? [])); ?>!
                        </h5>
                        <?php if($project->description): ?>
                            <p class="mil-up mil-mb-60"><?php echo $project->description; ?></p>
                        <?php endif; ?>

                        <a data-no-swup href="<?php echo e($project->url); ?>" target="_blank"
                            class="mil-link mil-dark mil-up  mil-arrow-place">
                            <span>Visit website</span>

                        </a>
                    </div>

                </div>
                <div class="col-lg-7">

                    <?php $__currentLoopData = $project->image_urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mil-image-frame mil-horizontal mil-up mil-mb-30">
                            <img src="<?php echo e($image); ?>" alt="<?php echo e($project->title); ?>">
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="mil-works-nav mil-up">
                <?php $__currentLoopData = getAdjacentProjects($project); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($nav['route']); ?>" class="mil-link mil-dark <?php echo e($nav['extraClass']); ?> <?php echo e($nav['iconClass']); ?>">
                        <span><?php echo e($nav['label']); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- project end -->

    <!-- call to action -->
    <section class="mil-soft-bg">
        <div class="container mil-p-120-120">
            <div class="row">
                <div class="col-lg-10">

                    <span class="mil-suptitle mil-suptitle-right mil-suptitle-dark mil-up">Looking to make your
                        mark? We'll help you turn <br> your project into a success story.</span>

                </div>
            </div>
            <div class="mil-center">
                <h2 class="mil-up mil-mb-60">Ready to bring your <span class="mil-thin">ideas to</span> life?
                    <br> We're <span class="mil-thin">here to help</span>
                </h2>
                <div class="mil-up"><a href="<?php echo e(route('contact')); ?>" class="mil-button mil-arrow-place"><span>Contact
                            us</span></a></div>
            </div>
        </div>
    </section>
    <!-- call to action end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\ashely-portfolio\resources\views\pages\project-details.blade.php ENDPATH**/ ?>