<!-- footer -->
<footer class="mil-dark-bg">
    <div class="mi-invert-fix">
        <div class="container mil-p-120-60">
            <div class="row justify-content-between">
                <div class="col-md-4 col-lg-4 mil-mb-60">
                    <div class="mil-muted mil-logo mil-up mil-mb-30">Portfolio.</div>
                    <p class="mil-light-soft mil-up mil-mb-30">Subscribe our newsletter:</p>
                    <form class="mil-subscribe-form mil-up">
                        <input type="text" id="subscriberEmail" placeholder="Enter our email">
                        <button type="submit" class="mil-button mil-icon-button-sm mil-arrow-place"
                            id="subscribeBtn"></button>
                    </form>
                </div>
                <div class="col-md-7 col-lg-6">
                    <div class="row justify-content-end">
                        <div class="col-md-6 col-lg-7">
                            <nav class="mil-footer-menu mil-mb-60">
                                <ul>
                                    <li class="mil-up <?php echo e(Route::is('home') ? 'mil-active' : ''); ?>">
                                        <a href="<?php echo e(route('home')); ?>">Home</a>
                                    </li>
                                    <li class="mil-up <?php echo e(Route::is('portfolio*') ? 'mil-active' : ''); ?>">
                                        <a href="<?php echo e(route('portfolio')); ?>">Portfolio</a>
                                    </li>
                                    <li class="mil-up <?php echo e(Route::is('services*') ? 'mil-active' : ''); ?>">
                                        <a href="<?php echo e(route('services')); ?>">Services</a>
                                    </li>
                                    <li class="mil-up <?php echo e(Route::is('contact*') ? 'mil-active' : ''); ?>">
                                        <a href="<?php echo e(route('contact')); ?>">Contact</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-md-6 col-lg-5">
                            <ul class="mil-menu-list mil-up mil-mb-60">
                                <?php $__currentLoopData = latestActiveProjects(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('projectDetails', $project->slug)); ?>" class="mil-light-soft">
                                            <?php echo e($project->title); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-between flex-sm-row-reverse">
                <div class="col-md-7 col-lg-6">
                    <div class="row justify-content-between">
                        <div class="col-md-6 col-lg-5 mil-mb-60">
                            <h6 class="mil-muted mil-up mil-mb-30"><?php echo e(generalSetting('more_configs.county')); ?></h6>
                            <p class="mil-light-soft mil-up"><?php echo e(generalSetting('more_configs.address')); ?>,
                                <?php echo e(generalSetting('more_configs.city')); ?>,
                                <span class="mil-no-wrap"><?php echo e(generalSetting('more_configs.phone')); ?></span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-6 mil-mb-60">
                    <div class="mil-vert-between">
                        <div class="mil-mb-30">
                            <ul class="mil-social-icons mil-up">
                                <?php if(generalSetting('social_network.x_twitter')): ?>
                                    <li>
                                        <a href="<?php echo e(generalSetting('social_network.x_twitter')); ?>" target="_blank"
                                            class="social-icon">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(generalSetting('social_network.github')): ?>
                                    <li>
                                        <a href="<?php echo e(generalSetting('social_network.github')); ?>" target="_blank"
                                            class="social-icon">
                                            <i class="fab fa-github"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(generalSetting('social_network.linkedin')): ?>
                                    <li>
                                        <a href="<?php echo e(generalSetting('social_network.linkedin')); ?>" target="_blank"
                                            class="social-icon">
                                            <i class="fab fa-linkedin-in"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if(generalSetting('social_network.instagram')): ?>
                                    <li>
                                        <a href="<?php echo e(generalSetting('social_network.instagram')); ?>" target="_blank"
                                            class="social-icon">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <p class="mil-light-soft mil-up">
                            © Copyright <?php echo e(now()->year); ?> - Portfolio. All Rights Reserved.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer end --><?php /**PATH D:\Projects\ashely-portfolio\resources\views/layouts/footer.blade.php ENDPATH**/ ?>