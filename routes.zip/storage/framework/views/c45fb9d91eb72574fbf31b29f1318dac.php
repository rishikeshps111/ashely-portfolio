<?php echo value($html); ?>

<?php /**PATH D:\Projects\ashely-portfolio\vendor\filament\support\resources\views\anonymous-partial.blade.php ENDPATH**/ ?>