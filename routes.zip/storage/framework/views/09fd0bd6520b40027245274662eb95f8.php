<!-- scrollbar progress -->
<div class="mil-progress-track">
    <div class="mil-progress"></div>
</div>
<!-- scrollbar progress end --><?php /**PATH D:\Projects\ashely-portfolio\resources\views\includes\progress-bar.blade.php ENDPATH**/ ?>