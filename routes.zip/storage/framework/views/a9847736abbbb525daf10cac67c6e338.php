<!-- menu -->
<div class="mil-menu-frame">
    <!-- frame clone -->
    <div class="mil-frame-top">
        <a href="<?php echo e(route('home')); ?>" class="mil-logo">A.</a>
        <div class="mil-menu-btn">
            <span></span>
        </div>
    </div>
    <!-- frame clone end -->
    <div class="container">
        <div class="mil-menu-content">
            <div class="row">
                <div class="col-xl-5">
                    <nav class="mil-main-menu" id="swupMenu">
                        <ul>
                            <li class="mil-has-children <?php echo e(Route::is('home') ? 'mil-active' : ''); ?>">
                                <a href="<?php echo e(route('home')); ?>">Home</a>
                            </li>
                            <li class="mil-has-children <?php echo e(Route::is('portfolio*') ? 'mil-active' : ''); ?>">
                                <a href="<?php echo e(route('portfolio')); ?>">Portfolio</a>
                            </li>
                            <li class="mil-has-children <?php echo e(Route::is('services*') ? 'mil-active' : ''); ?>">
                                <a href="<?php echo e(route('services')); ?>">Services</a>
                            </li>
                            <li class="mil-has-children <?php echo e(Route::is('contact*') ? 'mil-active' : ''); ?>">
                                <a href="<?php echo e(route('contact')); ?>">Contact</a>
                            </li>
                        </ul>
                    </nav>

                </div>
                <div class="col-xl-7">
                    <div class="mil-menu-right-frame">
                        <div class="mil-animation-in">
                            <div class="mil-animation-frame">
                                <div class="mil-animation mil-position-1 mil-scale" data-value-1="2" data-value-2="2">
                                </div>
                            </div>
                        </div>
                        <div class="mil-menu-right">
                            <div class="row">
                                <div class="col-lg-8 mil-mb-60">
                                    <h6 class="mil-muted mil-mb-30">Projects</h6>
                                    <ul class="mil-menu-list">
                                        <?php $__currentLoopData = latestActiveProjects(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('projectDetails', $project->slug)); ?>"
                                                    class="mil-light-soft">
                                                    <?php echo e($project->title); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <div class="col-lg-4 mil-mb-60">
                                    <h6 class="mil-muted mil-mb-30"><?php echo e(generalSetting('more_configs.county')); ?>

                                    </h6>
                                    <p class="mil-light-soft mil-up"><?php echo e(generalSetting('more_configs.address')); ?>,
                                        <?php echo e(generalSetting('more_configs.city')); ?>, <span
                                            class="mil-no-wrap"><?php echo e(generalSetting('more_configs.phone')); ?></span>
                                    </p>

                                </div>
                            </div>
                            <div class="mil-divider mil-mb-60"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- menu --><?php /**PATH D:\Projects\ashely-portfolio\resources\views\layouts\header.blade.php ENDPATH**/ ?>