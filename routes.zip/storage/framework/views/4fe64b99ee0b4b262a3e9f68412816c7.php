<!-- curtain -->
<div class="mil-curtain"></div>
<!-- curtain end --><?php /**PATH D:\Projects\ashely-portfolio\resources\views\includes\curtain.blade.php ENDPATH**/ ?>