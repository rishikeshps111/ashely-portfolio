<!-- jQuery js -->
<script src="<?php echo e(asset('assets/js/plugins/jquery.min.js')); ?>"></script>
<!-- swup js -->
<script src="<?php echo e(asset('assets/js/plugins/swup.min.js')); ?>"></script>
<!-- swiper js -->
<script src="<?php echo e(asset('assets/js/plugins/swiper.min.js')); ?>"></script>
<!-- fancybox js -->
<script src="<?php echo e(asset('assets/js/plugins/fancybox.min.js')); ?>"></script>
<!-- gsap js -->
<script src="<?php echo e(asset('assets/js/plugins/gsap.min.js')); ?>"></script>
<!-- scroll smoother -->
<script src="<?php echo e(asset('assets/js/plugins/smooth-scroll.js')); ?>"></script>
<!-- scroll trigger js -->
<script src="<?php echo e(asset('assets/js/plugins/ScrollTrigger.min.js')); ?>"></script>
<!-- scroll to js -->
<script src="<?php echo e(asset('assets/js/plugins/ScrollTo.min.js')); ?>"></script>
<!-- ashley js -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script><?php /**PATH D:\Projects\ashely-portfolio\resources\views/layouts/script.blade.php ENDPATH**/ ?>